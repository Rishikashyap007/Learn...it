import React from 'react'

const Navbar = () => {
  return (
    <>
            <main>

                
        <section class="testimonials-section">


        <section class="section-1">


            <section class="author">

                <img class="author-img" src="https://tse3.mm.bing.net/th?id=OIP.sKEc_OmcxLXvCoE_LOQqRAAAAA&pid=Api&P=0&h=180" alt="author-img"/>
                <section class="author-info">

                    <p class="author-name">Daniel Clifford</p>
                    <p class="author-describtion">Verified Graduate</p>
                </section>
            </section>
            
            <section class="highlight-content">

                <p>I received a job offer mid-course, and the subjects I learned
                    were current, if not more so, in the company I joined. I
                    honestly feel I got every penny's worth.</p>
            </section>
            
            <section class="content">

                <q>I was an EMT for many years before I joined the bootcamp. I've been looking to make a
                    transition and have heard some people who had an amazing experience here. I signed up for
                    the free intro course and found it incredibly fun! I enrolled shortly thereafter, The next 12
                    weeks was the best- and most grueling - time of my life. Since completing the course, I've
                    successfully switched careers, working as a Software Engineer at a VR startup.</q>
            </section>
        </section>

        <section class="section-2">

            
            <section class="author">

                <img class="author-img" src="https://tse4.explicit.bing.net/th?id=OIP.3dCaxs7dL2vi1FTLTOuevQAAAA&pid=Api&P=0&h=180" alt="author-img"/>
                <section class="author-info">

                    <p class="author-name">Jonathan Walters</p>
                    <p class="author-describtion">Verified Graduate</p>
                </section>
            </section>
            
            <section class="highlight-content">

                <p>The team was very
                    supportive and kept me
                    motivated
                </p>
            </section>
            
            <section class="content">

                <q>I started as a total newble with
                    virtually no coding skills. I now work
                    as a mobile engineer for a big
                    company. This was one of the best
                    investments I've made in myself.</q>
            </section>
        </section>

        <section class="section-3">

            
            <section class="author">

                <img class="author-img" src="https://tse1.mm.bing.net/th?id=OIP.fWX79DDardtfj89p_ExesAHaHa&pid=Api&P=0&h=180" alt="author-img"/>
                <section class="author-info">

                    <p class="author-name">Kira Whittle</p>
                    <p class="author-describtion">Verified Graduate</p>
                </section>
            </section>
            
            <section class="highlight-content">

                <p>Such a life-changing
                    experience. Highly
                    recommended!
                </p>
            </section>
            
            <section class="content">

                <q>Before joining the bootcamp, I've
                    never written a line of code, I needed
                    some structure from professionals
                    who can help me learn programming
                    step by step. I was encouraged to
                    enroll by a former student of theirs
                    who can only say wonderful things
                    about the program. The entire
                    curriculum and staff did not
                    disappoint. They were very hands-on
                    and I never had to wait long for
                    assistance. The agile team project, in
                    particular, was outstanding. It took
                    my learning to the next level in a way
                    that no tutorial could ever have, in
                    fact, I've often referred to it during
                    interviews as an example of my
                    developent experience. It certainly
                    helped me land a job as a full-stack
                    developer after receiving multiple
                    offers, 100% recommend!</q>
            </section>
        </section>

        <section class="section-4">

            
            <section class="author">

                <img class="author-img" src="https://tse4.mm.bing.net/th?id=OIP.wgZdcVPH39wDQWlAwBo1jgAAAA&pid=Api&P=0&h=180" alt="author-img"/>
                <section class="author-info">

                    <p class="author-name">Jeanette Harmon</p>
                    <p class="author-describtion">Verified Graduate</p>
                </section>
            </section>
            
            <section class="highlight-content">

                <p>An overall wonderful
                    and rewarding
                    experience
                </p>
            </section>
            
            <section class="content">

                <q>Thank you for the wonderful
                    experience! I now have a job I really
                    enjoy, and make a good living while
                    doing something I love.</q>
            </section>
        </section>

        <section class="section-5">

            
            <section class="author">

                <img class="author-img" src="https://tse1.mm.bing.net/th?id=OIP.U76Tao4ynRFL6Nb-3WCaWQHaHa&pid=Api&P=0&h=180" alt="author-img"/>
                <section class="author-info">

                    <p class="author-name">Patrick Abrams</p>
                    <p class="author-describtion">Verified Graduate</p>
                </section>
            </section>
            
            <section class="highlight-content">

                <p>Awesome teaching support from TAs who did the bootcamp
                    themselves. Getting guidance from them and learning from
                    their experiences was easy.
                </p>
            </section>
            
            <section class="content">

                <q>The staff seem genuinely concerned about my progress which I find really refreshing. The
                    program gave me the confidence necessary to be able to go out in the world and present
                    myself as a capable junior developer. The standard is above the rest. You will get the
                    personal attention you need from an incredible community of smart and amazing people.</q>
            </section>
        </section>
        </section>
        </main> 

        <main>

        

</main> 
    </>
    
    
  )
}

export default Navbar
